# Backend Auth System

## Setup

1. Install dependencies
   npm install

2. Start server
   node server.js

## APIs

POST /api/register
POST /api/login
GET /api/profile (Protected - send email in header)
GET /api/users (Admin only)