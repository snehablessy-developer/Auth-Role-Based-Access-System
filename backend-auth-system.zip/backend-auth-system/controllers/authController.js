const { users } = require("../data/database");

let idCounter = 2;

// Register User
const registerUser = (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const existingUser = users.find(user => user.email === email);

  if (existingUser) {
    return res.status(400).json({ message: "Email already exists" });
  }

  const newUser = {
    id: idCounter++,
    name,
    email,
    password,
    role: "user"
  };

  users.push(newUser);

  res.status(201).json({
    message: "User registered successfully",
    user: newUser
  });
};

// Login User
const loginUser = (req, res) => {
  const { email, password } = req.body;

  const user = users.find(
    user => user.email === email && user.password === password
  );

  if (!user) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  res.json({
    message: "Login successful",
    user
  });
};

// Get Profile
const getProfile = (req, res) => {
  res.json({
    message: "Profile fetched successfully",
    user: req.user
  });
};

// Get All Users (Admin only)
const getAllUsers = (req, res) => {
  res.json(users);
};

module.exports = {
  registerUser,
  loginUser,
  getProfile,
  getAllUsers
};