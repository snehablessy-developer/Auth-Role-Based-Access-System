const express = require("express");
const router = express.Router();

const {
  registerUser,
  loginUser,
  getProfile,
  getAllUsers
} = require("../controllers/authController");

const {
  authMiddleware,
  adminMiddleware
} = require("../middleware/authMiddleware");

router.post("/register", registerUser);
router.post("/login", loginUser);
router.get("/profile", authMiddleware, getProfile);
router.get("/users", authMiddleware, adminMiddleware, getAllUsers);

module.exports = router;