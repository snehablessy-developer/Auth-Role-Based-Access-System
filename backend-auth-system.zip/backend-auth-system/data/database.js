const users = [
  {
    id: 1,
    name: "sneha",
    email: "sneha@gmail.com",
    password: "123456",
    role: "user"
  },
  {
  id: 2,
    name: "Admin",
    email: "admin@gmail.com",
    password: "admin123",
    role: "admin"
  }
];

module.exports = { users };