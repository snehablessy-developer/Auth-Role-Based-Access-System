const { users } = require("../data/database");

const authMiddleware = (req, res, next) => {
  const email = req.headers.email;

  if (!email) {
    return res.status(401).json({ message: "Unauthorized. Email header required." });
  }

  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(401).json({ message: "User not found." });
  }

  req.user = user;
  next();
};

const adminMiddleware = (req, res, next) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Access denied. Admin only." });
  }
  next();
};

module.exports = { authMiddleware, adminMiddleware };